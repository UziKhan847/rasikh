/// Turns a stream of short-window transcripts into "the reciter is at word N".
///
/// The model re-transcribes the last few seconds of audio every few hundred
/// milliseconds, so consecutive transcripts overlap heavily. The aligner only
/// looks at the *tail* of each transcript and asks: which word in the mushaf
/// does this tail end on? Because the text is fixed, this is far cheaper and
/// more robust than general speech recognition.
///
/// Pure Dart: runs inside the ASR isolate and can be tested on a desktop.
library;

import 'dart:math' as math;

import 'quran_text.dart';

enum WordStatus {
  /// Heard and matches the mushaf.
  correct,

  /// Passed over, but the audio window did not clearly contain it (e.g. it was
  /// recited quickly or the window started after it). Not a mistake.
  unclear,

  /// Heard something different in this word's place. Treat as a soft hint:
  /// misrecognitions also land here.
  mismatch,

  /// Nothing heard for this word between two matched neighbours.
  skipped,
}

class WordMark {
  const WordMark(this.index, this.status, this.similarity);
  final int index; // global word index
  final WordStatus status;
  final double similarity;

  @override
  String toString() => '$index:${status.name}';
}

sealed class AlignEvent {
  const AlignEvent();
}

/// The reciter has moved forward; [marks] covers every newly passed word.
class ProgressEvent extends AlignEvent {
  const ProgressEvent(this.lastConfirmed, this.marks);
  final int lastConfirmed;
  final List<WordMark> marks;
}

/// The reciter started somewhere else (another ayah, page or surah, or went
/// back to repeat). [lastConfirmed] is the word they are now on.
class JumpEvent extends AlignEvent {
  const JumpEvent(this.lastConfirmed);
  final int lastConfirmed;
}

/// Several consecutive windows did not match anything near the current
/// position. Discovery mode is now searching the whole Quran.
class LostEvent extends AlignEvent {
  const LostEvent();
}

class AlignerSettings {
  const AlignerSettings({
    this.tailWords = 4,
    this.lookahead = 12,
    this.matchThreshold = 0.62,
    this.jumpPenalty = 0.015,
    this.confirmHits = 2,
    this.lostAfter = 6,
    this.discoveryTailWords = 6,
    this.discoveryThreshold = 0.72,
    this.maxBigramFanout = 300,
    this.surahHintBonus = 0.05,
    this.correctAt = 0.75,
    this.mismatchBelow = 0.5,
    this.gapCost = 0.6,
  });

  /// How many trailing transcript words are matched against the mushaf.
  final int tailWords;

  /// How far ahead of the current word tracking will look.
  final int lookahead;
  final double matchThreshold;

  /// Score penalty per word of forward jump, so near matches win ties.
  final double jumpPenalty;

  /// Consecutive windows that must agree before the newest word is confirmed.
  final int confirmHits;

  /// Consecutive non-matching windows before switching to discovery.
  final int lostAfter;
  final int discoveryTailWords;
  final double discoveryThreshold;

  /// Bigrams that occur more often than this are too common to locate by.
  final int maxBigramFanout;
  final double surahHintBonus;

  /// Word classification thresholds and alignment gap cost.
  final double correctAt;
  final double mismatchBelow;
  final double gapCost;
}

class RecitationAligner {
  RecitationAligner(List<QuranWord> words,
      {this.settings = const AlignerSettings()})
      : _norm = List<String>.unmodifiable(
            words.map((w) => QuranNormalizer.word(w.text))),
        _surahOf = List<int>.unmodifiable(words.map((w) => w.surah)) {
    _buildBigramIndex();
  }

  final AlignerSettings settings;
  final List<String> _norm;
  final List<int> _surahOf;
  final Map<String, List<int>> _bigrams = {};

  int _confirmed = -1; // last confirmed word; -1 = nothing yet
  bool _hasPosition = false;
  int _pending = -1;
  int _hits = 0;
  int _misses = 0;
  bool _lost = false;
  int? _surahHint;

  int get lastConfirmed => _confirmed;
  int get wordCount => _norm.length;

  /// Call when the user opens a page / taps "start" on an ayah. [index] is the
  /// first word they are expected to recite.
  void setPosition(int index, {int? surahHint}) {
    _confirmed = index - 1;
    _hasPosition = true;
    _surahHint = surahHint ?? _surahOf[index.clamp(0, _norm.length - 1)];
    _resetTracking();
  }

  /// Call when there is no expected position (e.g. "identify what I recite").
  void clearPosition({int? surahHint}) {
    _confirmed = -1;
    _hasPosition = false;
    _surahHint = surahHint;
    _resetTracking();
  }

  void _resetTracking() {
    _pending = -1;
    _hits = 0;
    _misses = 0;
    _lost = false;
  }

  /// Feed one window's transcript (already split + normalized with
  /// [QuranNormalizer.words]). Returns zero or more events.
  List<AlignEvent> update(List<String> hyp) {
    if (hyp.isEmpty) return const [];

    if (!_hasPosition || _lost) {
      return _discover(hyp);
    }

    final t = math.min(settings.tailWords, hyp.length);
    final tail = hyp.sublist(hyp.length - t);

    // Single-word tails are ambiguous (short common words are everywhere),
    // so they may only confirm "still here" or "next word".
    final reach = t == 1 ? 1 : settings.lookahead;
    final from = math.max(0, _confirmed);
    final to = math.min(_norm.length - 1, _confirmed + reach);

    var bestJ = -1;
    var bestScore = -1.0;
    for (var j = from; j <= to; j++) {
      final s = _tailScore(tail, j) -
          settings.jumpPenalty * math.max(0, j - (_confirmed + 1));
      if (s > bestScore) {
        bestScore = s;
        bestJ = j;
      }
    }

    if (bestScore < settings.matchThreshold) {
      _misses++;
      if (_misses >= settings.lostAfter && hyp.length >= 3) {
        _lost = true;
        final events = <AlignEvent>[const LostEvent()];
        events.addAll(_discover(hyp));
        return events;
      }
      return const [];
    }

    _misses = 0;
    if (bestJ == _pending) {
      _hits++;
    } else {
      _pending = bestJ;
      _hits = 1;
    }

    // The newest word needs [confirmHits] agreeing windows; anything before it
    // is confirmed as soon as the tail (2+ words) has moved past it.
    final target = _hits >= settings.confirmHits
        ? bestJ
        : (t >= 2 ? bestJ - 1 : _confirmed);

    if (target <= _confirmed) return const [];

    final marks = _classify(hyp, _confirmed + 1, target);
    _confirmed = target;
    _surahHint = _surahOf[target];
    return [ProgressEvent(target, marks)];
  }

  // Average similarity of [tail] against the mushaf words ending at [end].
  double _tailScore(List<String> tail, int end) {
    final t = tail.length;
    var sum = 0.0;
    for (var i = 0; i < t; i++) {
      final r = end - (t - 1) + i;
      if (r < 0) continue;
      sum += i == t - 1
          ? partialWordSimilarity(tail[i], _norm[r])
          : wordSimilarity(tail[i], _norm[r]);
    }
    return sum / t;
  }

  // ---------------------------------------------------------------- discovery

  void _buildBigramIndex() {
    for (var i = 1; i < _norm.length; i++) {
      final key = '${_norm[i - 1]} ${_norm[i]}';
      (_bigrams[key] ??= <int>[]).add(i);
    }
  }

  List<AlignEvent> _discover(List<String> hyp) {
    final t = math.min(settings.discoveryTailWords, hyp.length);
    if (t < 3) return const [];
    final tail = hyp.sublist(hyp.length - t);

    final votes = <int, int>{};
    var usable = 0;
    for (var k = 1; k < t; k++) {
      final hits = _bigrams['${tail[k - 1]} ${tail[k]}'];
      if (hits == null || hits.length > settings.maxBigramFanout) continue;
      usable++;
      for (final idx in hits) {
        final end = idx + (t - 1 - k);
        if (end < _norm.length) votes[end] = (votes[end] ?? 0) + 1;
      }
    }
    if (votes.isEmpty) return const [];

    final minVotes = usable >= 2 ? 2 : 1;
    final candidates = votes.entries.where((e) => e.value >= minVotes).toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    var bestEnd = -1;
    var bestScore = -1.0;
    for (final c in candidates.take(12)) {
      var s = _tailScore(tail, c.key);
      if (_surahHint != null && _surahOf[c.key] == _surahHint) {
        s += settings.surahHintBonus;
      }
      if (_hasPosition) {
        // Mild preference for staying near where they were.
        final dist = (c.key - _confirmed).abs();
        if (dist < 300) s += 0.03;
      }
      if (s > bestScore) {
        bestScore = s;
        bestEnd = c.key;
      }
    }

    if (bestScore < settings.discoveryThreshold) return const [];

    _confirmed = bestEnd;
    _hasPosition = true;
    _surahHint = _surahOf[bestEnd];
    _resetTracking();
    return [JumpEvent(bestEnd)];
  }

  // ----------------------------------------------------------- classification

  /// Aligns the whole window transcript against mushaf words [from..b] and
  /// labels each one. The transcript is free at both ends (it also contains
  /// words before [a] and possibly the word after [b]).
  List<WordMark> _classify(List<String> hyp, int from, int b) {
    // Include up to two already-confirmed words as anchors, so a skip right
    // at the start of the new range still sits between two matches.
    final a = math.max(0, from - 2);
    final ref = _norm.sublist(a, b + 1);
    final m = ref.length, h = hyp.length;
    final g = settings.gapCost;

    // dp[i][k]: best cost aligning ref[0..i) with hyp[..k) (free hyp prefix).
    final dp = List.generate(m + 1, (_) => List<double>.filled(h + 1, 0));
    final sim = List.generate(m, (_) => List<double>.filled(h, 0));
    for (var i = 1; i <= m; i++) {
      dp[i][0] = i * g;
      for (var k = 1; k <= h; k++) {
        // The last transcript word may be cut off mid-word.
        final s = k == h
            ? partialWordSimilarity(hyp[k - 1], ref[i - 1])
            : wordSimilarity(ref[i - 1], hyp[k - 1]);
        sim[i - 1][k - 1] = s;
        final diag = dp[i - 1][k - 1] + (1 - s);
        final skipRef = dp[i - 1][k] + g;
        final extraHyp = dp[i][k - 1] + g;
        dp[i][k] = math.min(diag, math.min(skipRef, extraHyp));
      }
    }

    // Free hyp suffix: end anywhere in the last row.
    var k = 0;
    for (var c = 1; c <= h; c++) {
      if (dp[m][c] < dp[m][k]) k = c;
    }

    final status = List<WordStatus>.filled(m, WordStatus.unclear);
    final sims = List<double>.filled(m, 0);
    final aligned = List<bool>.filled(m, false);
    var i = m;
    const eps = 1e-9;
    while (i > 0) {
      if (k > 0 &&
          (dp[i][k] - (dp[i - 1][k - 1] + (1 - sim[i - 1][k - 1]))).abs() <
              eps) {
        final s = sim[i - 1][k - 1];
        sims[i - 1] = s;
        aligned[i - 1] = true;
        status[i - 1] = s >= settings.correctAt
            ? WordStatus.correct
            : (s < settings.mismatchBelow
                ? WordStatus.mismatch
                : WordStatus.unclear);
        i--;
        k--;
      } else if ((dp[i][k] - (dp[i - 1][k] + g)).abs() < eps) {
        status[i - 1] = WordStatus.skipped; // revisited below
        i--;
      } else {
        k--;
      }
    }

    // A gap only counts as "skipped" when real matches surround it inside
    // this range; leading gaps mean the window simply did not cover the word.
    final firstAligned = aligned.indexOf(true);
    final lastAligned = aligned.lastIndexOf(true);
    for (var r = 0; r < m; r++) {
      if (status[r] == WordStatus.skipped &&
          (firstAligned == -1 || r < firstAligned || r > lastAligned)) {
        status[r] = WordStatus.unclear;
      }
    }

    return [
      for (var r = from - a; r < m; r++) WordMark(a + r, status[r], sims[r]),
    ];
  }
}
