# Offline recitation follow-along for Flutter

Drop-in feature: listens to the reciter, highlights the current word, detects
when they jump elsewhere, and flags likely skipped / wrong words. Fully
on-device, no server.

```
mic (UI isolate) ──bytes──▶ worker isolate: Silero VAD → quran-asr-small → aligner
                                                                        │
UI ◀──────────── ProgressEvent / JumpEvent / LostEvent ─────────────────┘
```

| File | Role |
|---|---|
| `lib/recitation/recitation_engine.dart` | Public API. Owns the mic, spawns the worker. |
| `lib/recitation/asr_worker.dart` | Background isolate: VAD, sliding-window decoding, aligner. |
| `lib/recitation/recitation_aligner.dart` | Transcript → word position, jump discovery, mistake labels. Pure Dart. |
| `lib/recitation/quran_text.dart` | `QuranWord`, Arabic normalization, word similarity. Pure Dart. |
| `lib/recitation/model_files.dart` | Downloads the model on first use, copies the VAD asset. |
| `tool/simulate.dart` | Desktop simulation of the aligner (no phone, no model needed). |

## 1. Dependencies

```yaml
dependencies:
  sherpa_onnx: 1.13.8      # API verified against this version
  record: ^6.0.0
  path_provider: ^2.1.0
  http: ^1.2.0
  crypto: ^3.0.3

flutter:
  assets:
    - assets/models/silero_vad.onnx
```

Get `silero_vad.onnx` (≈0.6 MB) from
`https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/silero_vad.onnx`.

Platform setup:
- **Android**: `<uses-permission android:name="android.permission.RECORD_AUDIO"/>`
  and `INTERNET` (for the one-time model download). Ship an App Bundle so each
  device only gets its own ABI's native libraries.
- **iOS**: add `NSMicrophoneUsageDescription` to `Info.plist`. If your app also
  plays recitation audio, test switching between playback and recording.

## 2. Build the word list once

The aligner needs every word of the mushaf in reading order as `QuranWord`s.
Use QUL's word-by-word **Uthmani** data (qul.tarteel.ai): the model writes
Uthmani letters, so matching against Uthmani text scores best even if your UI
shows another script. The index of a word in this list is the "global word
index" used everywhere in the API, so map it to your page/line layout (QUL's
mushaf layout data has that mapping).

## 3. Use it

```dart
// When the reader screen opens:
final files = await RecitationModelFiles.locate();
if (!await files.isReady) {
  await files.ensure(onProgress: (p) => setState(() => _download = p));
}
_engine = await RecitationEngine.spawn(WorkerConfig(
  modelPath: files.modelPath,
  tokensPath: files.tokensPath,
  vadPath: files.vadPath,
  words: quranWords,           // List<QuranWord>, built once
));

_sub = _engine.events.listen((e) {
  switch (e) {
    case ProgressEvent(:final lastConfirmed, :final marks):
      // Highlight up to lastConfirmed; colour marks by status.
      // Treat mismatch/skipped as soft hints, e.g. show after the ayah ends.
      setState(() { _current = lastConfirmed; _applyMarks(marks); });
    case JumpEvent(:final lastConfirmed):
      _scrollToWord(lastConfirmed);   // they started elsewhere
    case LostEvent():
      setState(() => _searching = true);
  }
});

// When the user taps the mic:
final ok = await _engine.start(fromWord: firstWordOnCurrentPage);
// Page turn / tap on an ayah / "repeat from here":
_engine.setPosition(wordIndex);
// Leaving the screen:
await _engine.dispose();
```

Rebuild only the widgets for words whose state changed (e.g. a
`ValueNotifier` per line), not the whole page, on every event.

## 4. Tuning

All knobs are in `WorkerConfig` and `AlignerSettings`:

- `decodeEveryMs` (400) and `windowSeconds` (4.0): if a decode pass on your
  slowest phone takes over ~300 ms, try a 3 s window. Turn on
  `sendTranscripts: true` to see decode times and raw transcripts.
- `numThreads` (2): rarely worth raising.
- `matchThreshold`, `lookahead`, `lostAfter`: how eagerly tracking advances and
  how quickly it gives up and searches the whole Quran.
- `correctAt`, `mismatchBelow`, `gapCost`: how strict mistake labels are.

## 5. Testing plan

1. `dart run tool/simulate.dart uthmani.json` runs the aligner against a
   simulated noisy reciter (skips, wrong words, jumps, repeats). Any JSON with
   `{"quran":[{"chapter","verse","text"}]}` works.
2. Record 20–30 real users (mixed ages, accents, cheap phones, noisy rooms),
   including deliberate mistakes. Replay the WAVs through the worker on a
   desktop and check where tracking stalls or mislabels words.
3. Profile on your lowest-end supported phone: decode time per pass and
   battery/thermal over a 20-minute session.

## Limits

- Word following is the reliable part. Mistake labels are hints: the model has
  memorized much of the Quran and can "hear" the correct word even when the
  reciter said something slightly different.
- No tajweed checking.
- Licenses: quran-asr-small is MIT; its training data includes CC-BY-4.0
  material (tarteel-ai/tlog). Credit both in your app's acknowledgements.
