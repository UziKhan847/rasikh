// Desktop simulation of the aligner: no model, no Flutter.
// Fakes a reciter + a noisy recognizer that re-transcribes the last 4 s every
// 0.4 s, then measures how the aligner tracks.
//
//   dart run tool/simulate.dart path/to/uthmani.json
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import '../lib/recitation/quran_text.dart';
import '../lib/recitation/recitation_aligner.dart';

final rnd = Random(7);

String noisy(String w, double subP, double delP) {
  const letters = 'ابتثجحخدذرزسشصضطظعغفقكلمنهوي';
  final b = StringBuffer();
  for (final c in w.split('')) {
    final r = rnd.nextDouble();
    if (r < delP) continue;
    if (r < delP + subP) {
      b.write(letters[rnd.nextInt(letters.length)]);
    } else {
      b.write(c);
    }
  }
  return b.toString();
}

class Spoken {
  Spoken(this.text, this.start, this.end, this.refIndex);
  final String text; // normalized, already noisy
  final double start, end;
  final int refIndex; // -1 for an inserted wrong word
}

/// Returns stats map.
Map<String, num> run(List<QuranWord> words, List<String> norm,
    {required int startIdx,
    required int count,
    Set<int> skip = const {},
    Map<int, String> replace = const {},
    int? jumpAt,
    int? jumpTo,
    bool givePosition = true,
    double subP = 0.05,
    double delP = 0.03,
    bool verbose = false}) {
  final al = RecitationAligner(words);
  if (givePosition) al.setPosition(startIdx);

  // Build the recitation timeline.
  final spoken = <Spoken>[];
  var tNow = 0.3;
  var idx = startIdx;
  for (var n = 0; n < count; n++) {
    if (jumpAt != null && n == jumpAt) idx = jumpTo!;
    if (!skip.contains(idx)) {
      final text = replace[idx] ?? norm[idx];
      final dur = 0.12 + 0.07 * text.length;
      spoken.add(Spoken(noisy(text, subP, delP), tNow, tNow + dur,
          replace.containsKey(idx) ? -2 : idx));
      tNow += dur + 0.05;
    }
    idx++;
  }
  final endTime = tNow + 1.5;

  final confirmedAt = <int, double>{};
  final marks = <int, WordStatus>{};
  var wrongJumps = 0, jumps = 0, losts = 0;
  for (var t = 0.4; t < endTime; t += 0.4) {
    final hyp = <String>[];
    for (final s in spoken) {
      if (s.end <= t - 4.0 || s.start >= t) continue;
      if (s.end <= t) {
        hyp.add(s.text);
      } else {
        final frac = (t - s.start) / (s.end - s.start);
        final n = (s.text.length * frac).floor();
        if (n > 0) hyp.add(s.text.substring(0, n));
      }
    }
    final h = hyp.where((w) => w.isNotEmpty).toList();
    for (final e in al.update(h)) {
      switch (e) {
        case ProgressEvent(:final lastConfirmed, marks: final ms):
          for (final m in ms) {
            confirmedAt[m.index] = t;
            marks[m.index] = m.status;
          }
          if (verbose) print('t=${t.toStringAsFixed(1)} progress -> $lastConfirmed $ms');
        case JumpEvent(:final lastConfirmed):
          jumps++;
          final expected = spoken.where((s) => s.end <= t).map((s) => s.refIndex).toList();
          final ok = expected.isNotEmpty && (expected.last - lastConfirmed).abs() <= 1;
          if (!ok) wrongJumps++;
          if (verbose) print('t=${t.toStringAsFixed(1)} JUMP -> $lastConfirmed ok=$ok');
          confirmedAt[lastConfirmed] = t;
        case LostEvent():
          losts++;
          if (verbose) print('t=${t.toStringAsFixed(1)} lost');
      }
    }
  }

  // Lag: time from end of spoken word to its confirmation.
  final lags = <double>[];
  for (final s in spoken) {
    final c = confirmedAt[s.refIndex];
    if (s.refIndex >= 0 && c != null) lags.add(c - s.end);
  }
  lags.sort();
  final spokenRefs = spoken.where((s) => s.refIndex >= 0).map((s) => s.refIndex).toSet();
  final covered = spokenRefs.where(confirmedAt.containsKey).length;
  final falseMistakes = marks.entries
      .where((e) =>
          spokenRefs.contains(e.key) &&
          !replace.containsKey(e.key) &&
          (e.value == WordStatus.mismatch || e.value == WordStatus.skipped))
      .length;
  final caughtSkips = skip.where((i) => marks[i] == WordStatus.skipped || marks[i] == WordStatus.mismatch).length;
  final caughtReplace = replace.keys.where((i) => marks[i] == WordStatus.mismatch || marks[i] == WordStatus.unclear).length;
  return {
    'words': spokenRefs.length,
    'covered%': 100 * covered / spokenRefs.length,
    'lagMedian': lags.isEmpty ? -1 : lags[lags.length ~/ 2],
    'lagP90': lags.isEmpty ? -1 : lags[(lags.length * 0.9).floor().clamp(0, lags.length - 1)],
    'falseMistakes': falseMistakes,
    'caughtSkips': caughtSkips,
    'caughtReplace': caughtReplace,
    'jumps': jumps,
    'wrongJumps': wrongJumps,
    'losts': losts,
  };
}

void main(List<String> args) {
  final data = jsonDecode(File(args[0]).readAsStringSync());
  final words = <QuranWord>[];
  for (final v in data['quran']) {
    var w = 0;
    for (final tok in (v['text'] as String).split(RegExp(r'\s+'))) {
      if (QuranNormalizer.word(tok).isEmpty) continue;
      words.add(QuranWord(surah: v['chapter'], ayah: v['verse'], word: ++w, text: tok));
    }
  }
  final norm = words.map((w) => QuranNormalizer.word(w.text)).toList();
  stdout.writeln('words: ${words.length}');
  final sw = Stopwatch()..start();
  RecitationAligner(words);
  stdout.writeln('index build: ${sw.elapsedMilliseconds} ms');

  int idxOf(int s, int a) => words.indexWhere((w) => w.surah == s && w.ayah == a);

  void show(String name, Map<String, num> r) => stdout.writeln(
      '$name: ${r.map((k, v) => MapEntry(k, v is double ? v.toStringAsFixed(2) : v))}');

  // 1. Clean-ish recitation of Al-Mulk from the start.
  final mulk = idxOf(67, 1);
  show('mulk tracking', run(words, norm, startIdx: mulk, count: 300));
  // 2. Noisier recognizer.
  show('mulk noisy', run(words, norm, startIdx: mulk, count: 300, subP: 0.10, delP: 0.06));
  // 3. Skipped words + wrong words.
  show('baqarah mistakes', run(words, norm,
      startIdx: idxOf(2, 255), count: 120,
      skip: {idxOf(2, 255) + 10, idxOf(2, 255) + 40, idxOf(2, 256) + 7},
      replace: {idxOf(2, 255) + 20: 'الارض', idxOf(2, 255) + 60: 'قالوا'}));
  // 4. Jump back to repeat (memorization style).
  final kahf = idxOf(18, 1);
  show('kahf repeat', run(words, norm, startIdx: kahf, count: 120, jumpAt: 60, jumpTo: kahf));
  // 5. Jump to a different surah.
  show('jump surah', run(words, norm, startIdx: mulk, count: 80, jumpAt: 40, jumpTo: idxOf(36, 1)));
  // 6. No position given (discovery from scratch).
  show('discover yasin', run(words, norm, startIdx: idxOf(36, 12), count: 60, givePosition: false));
  // 7. Timing of one update.
  final al = RecitationAligner(words)..setPosition(mulk);
  final hyp = norm.sublist(mulk, mulk + 8);
  sw.reset();
  for (var i = 0; i < 1000; i++) {
    al.setPosition(mulk);
    al.update(hyp);
  }
  stdout.writeln('update(): ${(sw.elapsedMicroseconds / 1000).toStringAsFixed(1)} us avg');
}
