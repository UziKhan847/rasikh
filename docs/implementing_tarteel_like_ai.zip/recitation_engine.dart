/// Public entry point for the recitation follow-along feature.
///
/// UI isolate responsibilities are deliberately tiny: own the microphone and
/// forward bytes. Model inference, VAD and alignment all run in the worker
/// isolate (asr_worker.dart).
library;

import 'dart:async';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:record/record.dart';

import 'asr_worker.dart';
import 'recitation_aligner.dart';

export 'asr_worker.dart' show TranscriptDebug, WorkerConfig;
export 'quran_text.dart' show QuranWord;
export 'recitation_aligner.dart'
    show AlignEvent, JumpEvent, LostEvent, ProgressEvent, WordMark, WordStatus;

class RecitationEngine {
  RecitationEngine._(
    this._isolate,
    this._toWorker,
    this._port,
    this._portSub,
    this._events,
    this._transcripts,
  );

  final Isolate _isolate;
  final SendPort _toWorker;
  final ReceivePort _port;
  final StreamSubscription<dynamic> _portSub;
  final StreamController<AlignEvent> _events;
  final StreamController<TranscriptDebug> _transcripts;

  final AudioRecorder _recorder = AudioRecorder();
  StreamSubscription<Uint8List>? _micSub;
  bool _disposed = false;

  /// Progress, jump and lost events from the aligner.
  Stream<AlignEvent> get events => _events.stream;

  /// Raw transcripts with timings; only emitted when
  /// [WorkerConfig.sendTranscripts] is true. Useful for a debug overlay.
  Stream<TranscriptDebug> get transcripts => _transcripts.stream;

  bool get isListening => _micSub != null;

  /// Loads the model in a background isolate. Takes a moment (model load plus
  /// building the Quran index), so call it when the reader screen opens, not
  /// when the user taps the mic.
  static Future<RecitationEngine> spawn(WorkerConfig config) async {
    final port = ReceivePort();
    final events = StreamController<AlignEvent>.broadcast();
    final transcripts = StreamController<TranscriptDebug>.broadcast();
    final ready = Completer<void>();
    SendPort? toWorker;

    final sub = port.listen((msg) {
      switch (msg) {
        case SendPort p:
          toWorker = p;
        case WorkerReady():
          if (!ready.isCompleted) ready.complete();
        case WorkerError(:final message):
          if (!ready.isCompleted) {
            ready.completeError(StateError(message));
          } else {
            events.addError(StateError(message));
          }
        case AlignEvent e:
          events.add(e);
        case TranscriptDebug t:
          transcripts.add(t);
      }
    });

    final isolate = await Isolate.spawn(
      recitationWorkerMain,
      <Object>[port.sendPort, config],
      debugName: 'recitation-asr',
    );

    try {
      await ready.future;
    } catch (_) {
      await sub.cancel();
      port.close();
      isolate.kill(priority: Isolate.immediate);
      rethrow;
    }

    return RecitationEngine._(
        isolate, toWorker!, port, sub, events, transcripts);
  }

  /// Start listening. Pass [fromWord] (global word index) when the user is on
  /// a known page/ayah; omit it to let discovery find where they are.
  ///
  /// Returns false if microphone permission was denied.
  Future<bool> start({int? fromWord, int? surahHint}) async {
    if (_disposed) throw StateError('RecitationEngine was disposed');
    if (_micSub != null) return true;
    if (!await _recorder.hasPermission()) return false;

    if (fromWord != null) {
      setPosition(fromWord, surahHint: surahHint);
    } else {
      _toWorker.send(ClearPositionCommand(surahHint: surahHint));
    }

    final stream = await _recorder.startStream(const RecordConfig(
      encoder: AudioEncoder.pcm16bits,
      sampleRate: kSampleRate,
      numChannels: 1,
      // Phone noise suppression can smear long vowels (madd). Test both
      // settings with real users before shipping.
      noiseSuppress: false,
      echoCancel: false,
    ));

    _micSub = stream.listen((bytes) {
      // Moves the bytes to the worker without copying them on this isolate.
      _toWorker.send(AudioChunk(TransferableTypedData.fromList([bytes])));
    });
    return true;
  }

  /// Tell the aligner where the reciter is expected to be (page turn, tap on
  /// an ayah, "repeat from here").
  void setPosition(int wordIndex, {int? surahHint}) {
    _toWorker.send(SetPositionCommand(wordIndex, surahHint: surahHint));
  }

  Future<void> stop() async {
    await _micSub?.cancel();
    _micSub = null;
    if (await _recorder.isRecording()) await _recorder.stop();
    _toWorker.send(const ResetAudioCommand());
  }

  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    await stop();
    await _recorder.dispose();
    _toWorker.send(const ShutdownCommand());
    // Give the worker a moment to free native memory, then make sure it's gone.
    await Future<void>.delayed(const Duration(milliseconds: 200));
    _isolate.kill(priority: Isolate.beforeNextEvent);
    await _portSub.cancel();
    _port.close();
    await _events.close();
    await _transcripts.close();
  }
}
