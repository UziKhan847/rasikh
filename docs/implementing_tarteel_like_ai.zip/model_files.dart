/// Getting the model files onto the device.
///
/// The ASR model (~36 MB) is downloaded on first use rather than bundled, so
/// your install size does not grow for users who never use the feature. The
/// Silero VAD model (~0.6 MB) is small enough to ship as an asset.
library;

import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

class RecitationModelFiles {
  RecitationModelFiles._(this.dir);

  /// Pin these to a specific commit instead of `main` (copy the commit hash
  /// from the model's "Files and versions" tab), or better, mirror the files
  /// on your own CDN so an upstream change can never break your app.
  static const String _base =
      'https://huggingface.co/Abdou/quran-asr-small/resolve/main';
  static const String modelFile = 'model.int8.onnx';
  static const String tokensFile = 'tokens.txt';

  /// Fill in after your first download (`shasum -a 256 model.int8.onnx`).
  /// Null skips the check.
  static const String? modelSha256 = null;

  static const String vadAsset = 'assets/models/silero_vad.onnx';

  final Directory dir;

  String get modelPath => '${dir.path}/$modelFile';
  String get tokensPath => '${dir.path}/$tokensFile';
  String get vadPath => '${dir.path}/silero_vad.onnx';

  static Future<RecitationModelFiles> locate() async {
    final support = await getApplicationSupportDirectory();
    final dir = Directory('${support.path}/quran_asr');
    await dir.create(recursive: true);
    return RecitationModelFiles._(dir);
  }

  Future<bool> get isReady async =>
      await File(modelPath).exists() &&
      await File(tokensPath).exists() &&
      await File(vadPath).exists();

  /// Downloads whatever is missing. [onProgress] receives 0..1 for the model.
  Future<void> ensure({void Function(double progress)? onProgress}) async {
    await _copyVadAsset();
    if (!await File(tokensPath).exists()) {
      await _download('$_base/$tokensFile', tokensPath);
    }
    if (!await File(modelPath).exists()) {
      await _download('$_base/$modelFile', modelPath, onProgress: onProgress);
      if (modelSha256 != null) {
        final digest = await sha256.bind(File(modelPath).openRead()).first;
        if (digest.toString() != modelSha256) {
          await File(modelPath).delete();
          throw StateError('Model checksum mismatch; download discarded.');
        }
      }
    }
  }

  Future<void> _copyVadAsset() async {
    final out = File(vadPath);
    if (await out.exists()) return;
    final data = await rootBundle.load(vadAsset);
    await out.writeAsBytes(
        data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
        flush: true);
  }

  static Future<void> _download(String url, String path,
      {void Function(double)? onProgress}) async {
    final client = http.Client();
    final part = File('$path.part');
    try {
      final res = await client.send(http.Request('GET', Uri.parse(url)));
      if (res.statusCode != 200) {
        throw HttpException('HTTP ${res.statusCode} for $url');
      }
      final total = res.contentLength ?? 0;
      var received = 0;
      final sink = part.openWrite();
      try {
        await for (final chunk in res.stream) {
          sink.add(chunk);
          received += chunk.length;
          if (total > 0) onProgress?.call(received / total);
        }
      } finally {
        await sink.close();
      }
      await part.rename(path); // only complete files get the real name
    } catch (_) {
      if (await part.exists()) await part.delete();
      rethrow;
    } finally {
      client.close();
    }
  }
}
