/// Quran text helpers shared by the aligner and the ASR worker.
///
/// Everything here is pure Dart (no Flutter, no FFI), so it runs in any
/// isolate and can be unit-tested on a desktop.
library;

/// One word of the mushaf, in reading order.
///
/// Build this list once from QUL's word-by-word data (Uthmani script).
/// [text] should be the Uthmani spelling: the model writes Uthmani letters,
/// so matching against Uthmani text gives the best scores, even if your UI
/// displays a different script.
class QuranWord {
  const QuranWord({
    required this.surah,
    required this.ayah,
    required this.word,
    required this.text,
  });

  final int surah;
  final int ayah;

  /// 1-based position of the word inside its ayah.
  final int word;
  final String text;
}

/// Reduces Uthmani or standard Arabic to a bare letter skeleton, so that model
/// output and mushaf text compare on equal terms.
///
/// The same function must be applied to both sides. After you download the
/// model, open its tokens.txt and check that every letter it can emit survives
/// this normalization (adjust [_letterMap] if not).
class QuranNormalizer {
  // Harakat, tanween, shadda, sukun, dagger alif, small high/low Quranic
  // marks, waqf signs, tatweel, and the extended Quranic mark block.
  static final RegExp _marks = RegExp(
    '[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640\u08D3-\u08FF]',
  );

  static const Map<String, String> _letterMap = {
    '\u0671': '\u0627', // ٱ alef wasla -> ا
    '\u0623': '\u0627', // أ
    '\u0625': '\u0627', // إ
    '\u0622': '\u0627', // آ
    '\u0672': '\u0627', // ٲ
    '\u0673': '\u0627', // ٳ
    '\u0649': '\u064A', // ى -> ي
    '\u0626': '\u064A', // ئ -> ي
    '\u06CC': '\u064A', // ی (Farsi yeh) -> ي
    '\u0624': '\u0648', // ؤ -> و
    '\u0629': '\u0647', // ة -> ه
    '\u06A9': '\u0643', // ک -> ك
    '\u0621': '', //       ء standalone hamza dropped
  };

  // Anything outside the basic Arabic letter block is removed after mapping.
  static final RegExp _nonLetter = RegExp('[^\u0621-\u064A]');

  // Word separators: whitespace plus the separator symbols some tokenizers
  // emit ("▁" sentencepiece, "|" CTC word boundary).
  static final RegExp _separators = RegExp('[\\s\u2581|]+');

  static String word(String w) {
    var s = w.replaceAll(_marks, '');
    if (s.isEmpty) return s;
    final b = StringBuffer();
    for (final rune in s.runes) {
      final ch = String.fromCharCode(rune);
      b.write(_letterMap[ch] ?? ch);
    }
    return b.toString().replaceAll(_nonLetter, '');
  }

  /// Splits a model transcript (or any Arabic text) into normalized words,
  /// dropping tokens that normalize to nothing (waqf signs, stray marks).
  static List<String> words(String text) => text
      .split(_separators)
      .map(word)
      .where((w) => w.isNotEmpty)
      .toList(growable: false);
}

/// Normalized similarity of two words in [0, 1] (1 = identical).
double wordSimilarity(String a, String b) {
  if (identical(a, b) || a == b) return 1.0;
  if (a.isEmpty || b.isEmpty) return 0.0;
  final d = _levenshtein(a, b);
  final longest = a.length > b.length ? a.length : b.length;
  return 1.0 - d / longest;
}

/// Similarity for a word the reciter may still be in the middle of: compares
/// the heard fragment against the same-length start of the expected word.
double partialWordSimilarity(String heard, String expected) {
  final full = wordSimilarity(heard, expected);
  if (heard.length < 2 || heard.length >= expected.length) return full;
  final prefix = wordSimilarity(heard, expected.substring(0, heard.length));
  final discounted = prefix * 0.9;
  return discounted > full ? discounted : full;
}

int _levenshtein(String a, String b) {
  final m = a.length, n = b.length;
  var prev = List<int>.generate(n + 1, (j) => j, growable: false);
  var cur = List<int>.filled(n + 1, 0, growable: false);
  for (var i = 1; i <= m; i++) {
    cur[0] = i;
    final ca = a.codeUnitAt(i - 1);
    for (var j = 1; j <= n; j++) {
      final cost = ca == b.codeUnitAt(j - 1) ? 0 : 1;
      final del = prev[j] + 1;
      final ins = cur[j - 1] + 1;
      final sub = prev[j - 1] + cost;
      cur[j] = del < ins ? (del < sub ? del : sub) : (ins < sub ? ins : sub);
    }
    final t = prev;
    prev = cur;
    cur = t;
  }
  return prev[n];
}
