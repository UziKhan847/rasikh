/// Background isolate that owns the model, the VAD and the aligner.
///
/// The UI isolate only forwards raw microphone bytes here and receives small
/// [AlignEvent]s back, so recognition never competes with rendering.
library;

import 'dart:async';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:sherpa_onnx/sherpa_onnx.dart' as so;

import 'quran_text.dart';
import 'recitation_aligner.dart';

const int kSampleRate = 16000;

class WorkerConfig {
  const WorkerConfig({
    required this.modelPath,
    required this.tokensPath,
    required this.vadPath,
    required this.words,
    this.numThreads = 2,
    this.windowSeconds = 4.0,
    this.decodeEveryMs = 400,
    this.speechHangoverMs = 700,
    this.resetAfterSilenceMs = 2500,
    this.sendTranscripts = false,
  });

  final String modelPath;
  final String tokensPath;
  final String vadPath;
  final List<QuranWord> words;

  /// 2 is a good default on phones; more threads rarely helps a 33M model and
  /// heats the device.
  final int numThreads;

  /// Length of audio re-transcribed on each pass.
  final double windowSeconds;

  /// Target gap between the starts of two passes. If a pass is slower than
  /// this on a weak phone, passes simply run back to back on the newest
  /// audio; stale audio is never decoded.
  final int decodeEveryMs;

  /// Keep decoding this long after the VAD stops hearing speech, so the last
  /// word of a phrase gets confirmed.
  final int speechHangoverMs;

  /// After this much silence the audio window is cleared, so a new phrase is
  /// not mixed with the end of the previous one.
  final int resetAfterSilenceMs;

  /// Send each raw transcript to the UI (for a debug overlay).
  final bool sendTranscripts;
}

// ------------------------------------------------------------------ messages

sealed class WorkerCommand {
  const WorkerCommand();
}

class AudioChunk extends WorkerCommand {
  AudioChunk(this.pcm16);

  /// Little-endian 16-bit mono PCM at 16 kHz, moved without copying.
  final TransferableTypedData pcm16;
}

class SetPositionCommand extends WorkerCommand {
  const SetPositionCommand(this.wordIndex, {this.surahHint});
  final int wordIndex;
  final int? surahHint;
}

class ClearPositionCommand extends WorkerCommand {
  const ClearPositionCommand({this.surahHint});
  final int? surahHint;
}

/// Drop buffered audio (e.g. when recording stops or the user changes page).
class ResetAudioCommand extends WorkerCommand {
  const ResetAudioCommand();
}

class ShutdownCommand extends WorkerCommand {
  const ShutdownCommand();
}

class WorkerReady {
  const WorkerReady();
}

class WorkerError {
  const WorkerError(this.message);
  final String message;
}

class TranscriptDebug {
  const TranscriptDebug(this.text, this.decodeMs, this.audioSeconds);
  final String text;
  final int decodeMs;
  final double audioSeconds;
}

// --------------------------------------------------------------- entry point

/// Spawn with `Isolate.spawn(recitationWorkerMain, [sendPort, config])`.
/// The first message sent back is this isolate's [SendPort].
Future<void> recitationWorkerMain(List<Object> args) async {
  final toMain = args[0] as SendPort;
  final cfg = args[1] as WorkerConfig;
  final inbox = ReceivePort();
  toMain.send(inbox.sendPort);

  final _Worker worker;
  try {
    // FFI bindings are per isolate, so this must run here, not on the UI side.
    so.initBindings();
    worker = _Worker(cfg, toMain);
  } catch (e) {
    toMain.send(WorkerError('Failed to start recognizer: $e'));
    inbox.close();
    return;
  }
  toMain.send(const WorkerReady());

  inbox.listen((msg) {
    try {
      switch (msg) {
        case AudioChunk(:final pcm16):
          worker.onAudio(pcm16.materialize().asUint8List());
        case SetPositionCommand(:final wordIndex, :final surahHint):
          worker.aligner.setPosition(wordIndex, surahHint: surahHint);
          worker.resetAudio();
        case ClearPositionCommand(:final surahHint):
          worker.aligner.clearPosition(surahHint: surahHint);
          worker.resetAudio();
        case ResetAudioCommand():
          worker.resetAudio();
        case ShutdownCommand():
          worker.free();
          inbox.close();
      }
    } catch (e) {
      toMain.send(WorkerError('$e'));
    }
  });
}

// ------------------------------------------------------------------- worker

class _Worker {
  _Worker(this.cfg, this.toMain)
      : ring = _Ring((cfg.windowSeconds * kSampleRate).round()),
        aligner = RecitationAligner(cfg.words) {
    recognizer = so.OfflineRecognizer(
      so.OfflineRecognizerConfig(
        model: so.OfflineModelConfig(
          zipformerCtc: so.OfflineZipformerCtcModelConfig(model: cfg.modelPath),
          tokens: cfg.tokensPath,
          numThreads: cfg.numThreads,
          debug: false,
        ),
      ),
    );
    vad = so.VoiceActivityDetector(
      config: so.VadModelConfig(
        sileroVad: so.SileroVadModelConfig(
          model: cfg.vadPath,
          threshold: 0.5,
          minSilenceDuration: 0.3,
          minSpeechDuration: 0.15,
          windowSize: _vadWindow,
          // Recitation phrases can be long; we only use isDetected(), so a
          // large limit avoids forced splits mid-phrase.
          maxSpeechDuration: 30.0,
        ),
        numThreads: 1,
        debug: false,
      ),
      bufferSizeInSeconds: 40,
    );
  }

  static const int _vadWindow = 512; // Silero's window at 16 kHz

  final WorkerConfig cfg;
  final SendPort toMain;
  final _Ring ring;
  final RecitationAligner aligner;
  late final so.OfflineRecognizer recognizer;
  late final so.VoiceActivityDetector vad;

  final Stopwatch _clock = Stopwatch()..start();
  final Float32List _vadBuf = Float32List(_vadWindow);
  int _vadFill = 0;
  int? _oddByte; // a chunk can end halfway through a 16-bit sample

  int _audioMs = 0; // audio clock, from samples received
  int _lastSpeechMs = -1 << 30;
  int _lastDecodeStartWall = -1 << 30;
  bool _decodeScheduled = false;
  bool _freed = false;
  bool _flushedSincePause = true;
  bool _clearedSincePause = true;

  void onAudio(Uint8List bytes) {
    final samples = _pcm16ToFloat(bytes);
    if (samples.isEmpty) return;
    ring.add(samples);
    _audioMs += samples.length * 1000 ~/ kSampleRate;

    // Feed the VAD in fixed windows.
    var i = 0;
    while (i < samples.length) {
      final take = (_vadWindow - _vadFill).clamp(0, samples.length - i);
      _vadBuf.setRange(_vadFill, _vadFill + take, samples, i);
      _vadFill += take;
      i += take;
      if (_vadFill == _vadWindow) {
        vad.acceptWaveform(_vadBuf); // copied into native memory by sherpa
        _vadFill = 0;
        if (vad.isDetected()) _lastSpeechMs = _audioMs;
        // We don't use VAD segments, only isDetected(); discard them so the
        // VAD's internal queue does not grow.
        while (!vad.isEmpty()) {
          vad.pop();
        }
      }
    }

    final silenceMs = _audioMs - _lastSpeechMs;
    if (silenceMs < cfg.speechHangoverMs) {
      _flushedSincePause = false;
      _clearedSincePause = false;
      if (_clock.elapsedMilliseconds - _lastDecodeStartWall >=
          cfg.decodeEveryMs) {
        _scheduleDecode();
      }
    } else if (!_flushedSincePause) {
      // One last pass right after the reciter pauses.
      _flushedSincePause = true;
      _scheduleDecode();
    } else if (!_clearedSincePause && silenceMs >= cfg.resetAfterSilenceMs) {
      _clearedSincePause = true;
      ring.clear();
    }
  }

  // Decoding is deferred with Timer.run so that any audio chunks that queued
  // up during the previous pass are absorbed first: each pass always sees the
  // newest audio, and a slow phone simply decodes less often.
  void _scheduleDecode() {
    if (_decodeScheduled) return;
    _decodeScheduled = true;
    Timer.run(() {
      _decodeScheduled = false;
      if (!_freed) _decode();
    });
  }

  void _decode() {
    _lastDecodeStartWall = _clock.elapsedMilliseconds;
    final audio = ring.snapshot();
    if (audio.length < kSampleRate * 0.3) return;
    final t0 = _clock.elapsedMilliseconds;

    final stream = recognizer.createStream();
    try {
      stream.acceptWaveform(samples: audio, sampleRate: kSampleRate);
      recognizer.decode(stream);
      final text = recognizer.getResult(stream).text;
      final hyp = QuranNormalizer.words(text);
      for (final e in aligner.update(hyp)) {
        toMain.send(e);
      }
      if (cfg.sendTranscripts) {
        toMain.send(TranscriptDebug(text, _clock.elapsedMilliseconds - t0,
            audio.length / kSampleRate));
      }
    } finally {
      stream.free();
    }
  }

  void resetAudio() {
    ring.clear();
    _vadFill = 0;
    _oddByte = null;
    vad.reset();
    _lastSpeechMs = -1 << 30;
    _flushedSincePause = true;
    _clearedSincePause = true;
  }

  void free() {
    _freed = true;
    vad.free();
    recognizer.free();
  }

  Float32List _pcm16ToFloat(Uint8List bytes) {
    Uint8List data = bytes;
    if (_oddByte != null) {
      data = Uint8List(bytes.length + 1)
        ..[0] = _oddByte!
        ..setRange(1, bytes.length + 1, bytes);
      _oddByte = null;
    }
    final n = data.length ~/ 2;
    if (data.length.isOdd) _oddByte = data[data.length - 1];
    final bd = ByteData.sublistView(data);
    final out = Float32List(n);
    for (var k = 0; k < n; k++) {
      out[k] = bd.getInt16(k * 2, Endian.little) / 32768.0;
    }
    return out;
  }
}

/// Fixed-size ring buffer holding the most recent audio window.
class _Ring {
  _Ring(int capacity) : _buf = Float32List(capacity);

  final Float32List _buf;
  int _write = 0;
  int _filled = 0;

  void add(Float32List x) {
    final cap = _buf.length;
    var src = x;
    if (src.length >= cap) {
      src = Float32List.sublistView(src, src.length - cap);
    }
    final first = (cap - _write).clamp(0, src.length);
    _buf.setRange(_write, _write + first, src);
    if (first < src.length) {
      _buf.setRange(0, src.length - first, src, first);
    }
    _write = (_write + src.length) % cap;
    _filled = (_filled + src.length).clamp(0, cap);
  }

  Float32List snapshot() {
    final cap = _buf.length;
    final out = Float32List(_filled);
    final start = (_write - _filled + cap) % cap;
    final first = (cap - start).clamp(0, _filled);
    out.setRange(0, first, _buf, start);
    if (first < _filled) out.setRange(first, _filled, _buf);
    return out;
  }

  void clear() {
    _write = 0;
    _filled = 0;
  }
}
