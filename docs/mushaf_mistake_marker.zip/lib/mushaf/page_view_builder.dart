import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mushaf_mistake_marker/tiles/mushaf/dual_page.dart';
import 'package:mushaf_mistake_marker/tiles/mushaf/single_page.dart';
import 'package:mushaf_mistake_marker/mushaf/changed_handler.dart';
import 'package:mushaf_mistake_marker/providers/page_mode.dart';
import 'package:mushaf_mistake_marker/providers/mushaf/page_controller.dart';
import 'package:mushaf_mistake_marker/providers/pages_provider.dart';

class MushafPageViewBuilder extends ConsumerStatefulWidget {
  const MushafPageViewBuilder({super.key, required this.constraints});

  final BoxConstraints constraints;

  @override
  ConsumerState<MushafPageViewBuilder> createState() => _MushafPagerState();
}

class _MushafPagerState extends ConsumerState<MushafPageViewBuilder>
    with AutomaticKeepAliveClientMixin {
  late int prevIndex;
  late final onPageHandler = PageChangedHandler(ref: ref);
  late final pages = ref.read(pagesProvider).value!;
  late final mshfPgCtrl = ref.read(mushafPgCtrlProvider);

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    prevIndex = mshfPgCtrl.initialPage;
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    final dualPgMode = ref.watch(pageModeProvider);

    return PageView.builder(
      reverse: true,
      controller: mshfPgCtrl,
      onPageChanged: (int index) async {
        final isSwipe = (index - prevIndex).abs() == 1;

        if (!isSwipe) {
          prevIndex = index;
          return;
        }

        prevIndex = await onPageHandler.onPageSwipe(
          prevIndex,
          index,
          dualPgMode,
        );
      },
      itemCount: dualPgMode ? 302 : 604,
      itemBuilder: (_, index) {
        if (dualPgMode) {
          final rightPage = index * 2;
          final leftPage = rightPage + 1;

          return MushafDualPageTile(
            constraints: widget.constraints,
            pageData: [pages.pagesData[rightPage], pages.pagesData[leftPage]],
            dualPageIndex: [rightPage, leftPage],
          );
        }
        return MushafSinglePageTile(
          constraints: widget.constraints,
          pageData: pages.pagesData[index],
          index: index,
        );
      },
    );
  }
}
