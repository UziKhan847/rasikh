import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mushaf_mistake_marker/enums.dart';
import 'package:mushaf_mistake_marker/providers/sprite/family/ele_mark_data_list.dart';

final pageHighlightsProvider = NotifierProvider.autoDispose
    .family<PageHighlightsNotifier, Map<String, HighlightType>, int>(
      PageHighlightsNotifier.new,
    );

class PageHighlightsNotifier extends Notifier<Map<String, HighlightType>> {
  PageHighlightsNotifier(this.index);
  final int index;

  @override
  Map<String, HighlightType> build() {
    final eleMarkData = ref.read(sprEleDataListProvider(index));

    if (eleMarkData.isEmpty) return {};

    return {for (final e in eleMarkData) e.key: e.highlight};
  }

  void update(String key, HighlightType mark) {
    final newMap = {...state}..[key] = mark;
    state = newMap;
  }

  void remove(String key) {
    final newMap = {...state}..remove(key);
    state = newMap;
  }
}
