// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'page_data.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PageData _$PageDataFromJson(Map<String, dynamic> json) => PageData(
  pNum: (json['pNum'] as num).toInt(),
  pSize: (json['pSize'] as List<dynamic>?)
      ?.map((e) => (e as num).toDouble())
      .toList(),
  hzNum: (json['hzNum'] as List<dynamic>)
      .map((e) => (e as num).toInt())
      .toSet(),
  rHzbNum: (json['rHzbNum'] as List<dynamic>)
      .map((e) => (e as num).toInt())
      .toSet(),
  rkNum: (json['rkNum'] as List<dynamic>)
      .map((e) => (e as num).toInt())
      .toSet(),
  mnzlNum: (json['mnzlNum'] as List<dynamic>)
      .map((e) => (e as num).toInt())
      .toSet(),
  sjdNum: (json['sjdNum'] as num?)?.toInt(),
  jzNum: (json['jzNum'] as List<dynamic>)
      .map((e) => (e as num).toInt())
      .toSet(),
  srNum: (json['srNum'] as List<dynamic>)
      .map((e) => (e as num).toInt())
      .toSet(),
  srVrsSets: (json['srVrsSets'] as Map<String, dynamic>).map(
    (k, e) => MapEntry(
      int.parse(k),
      (e as List<dynamic>).map((e) => (e as num).toInt()).toSet(),
    ),
  ),
);

Map<String, dynamic> _$PageDataToJson(PageData instance) => <String, dynamic>{
  'pNum': instance.pNum,
  'pSize': instance.pSize,
  'srNum': instance.srNum.toList(),
  'hzNum': instance.hzNum.toList(),
  'rHzbNum': instance.rHzbNum.toList(),
  'rkNum': instance.rkNum.toList(),
  'mnzlNum': instance.mnzlNum.toList(),
  'sjdNum': instance.sjdNum,
  'jzNum': instance.jzNum.toList(),
  'srVrsSets': instance.srVrsSets.map(
    (k, e) => MapEntry(k.toString(), e.toList()),
  ),
};
