// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pages.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Pages _$PagesFromJson(Map<String, dynamic> json) => Pages(
  pagesData: (json['pagesData'] as List<dynamic>)
      .map((e) => PageData.fromJson(e as Map<String, dynamic>))
      .toList(),
);

Map<String, dynamic> _$PagesToJson(Pages instance) => <String, dynamic>{
  'pagesData': instance.pagesData.map((e) => e.toJson()).toList(),
};
