import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mushaf_mistake_marker/custom_nav_bar/item.dart';
import 'package:mushaf_mistake_marker/providers/buttons/annotate_mode.dart';

class AnnotaterItem extends ConsumerWidget {
  const AnnotaterItem({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final annotateModeProv = ref.read(annotateModeProvider.notifier);
    final annotateMode = ref.watch(annotateModeProvider);
    final cs = Theme.of(context).colorScheme;
    final isSelected = annotateMode == .annotate;

    return NavBarItem(
      iconLabel: 'Annotate',
      isSelected: isSelected,
      onTap: () {
        annotateModeProv.setMode(.annotate);
      },
      child: Icon(
        isSelected ? Icons.chat_bubble : Icons.chat_bubble_outline_outlined,
        color: isSelected ? cs.primary : cs.onSurfaceVariant,
      ),
    );
  }
}
